var express = require('express');
var productModel = require('../model/productModel');
var router = express.Router();

router.get('/detail',function(req,res,next){
    productModel.load((req.query.lid)/1,(rows)=>{
        res.json(rows);
    })
})
router.get('/list',function(req,res,next){
    console.log(req.query.kw);
    console.log(req.query.pno);
    productModel.loadlist(req.query.kw,req.query.pno,(rows)=>{
        res.json(rows);
    })
})
router.post('/add',function(req,res,next){
    console.log(req.body)
    if(req.session.user){
        var user=req.session.user;
        var uid=user.uid;
        productModel.add(uid,req.body,(rows)=>{
            if(rows=='succ'){
                res.json({code:200,msg:"add succ"})
            }else{
                res.json({code:500,msg:"add err"})
            }
        })
    }else{
        res.json({code:300,msg:'login required'})
    }

})
module.exports = router;