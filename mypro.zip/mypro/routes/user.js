var express = require('express');
var userModel = require('../model/userModel');
var router = express.Router();


/* GET users listing. */
router.post('/login', function(req, res, next) {
  userModel.login(req.body,(result)=>{
    if(result=='err'){
      res.send(result)
    }else{
      var user={
        name:req.body.uname,uid:result
      };
      req.session.user=user;
      res.json({code:200,uid:result})
    }
  })
});
router.post('/register', function(req, res, next) {
  userModel.register(req.body,(uid)=>{
    res.json({'code':200,"msg":'succ',"uid":uid})
  })
});

module.exports = router;
