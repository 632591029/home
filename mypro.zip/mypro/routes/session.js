var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
    if(req.session.user){
        var user=req.session.user;
        var name=user.name;
        res.json({uname:name});
    }else{
        res.send('�㻹û�е�¼���ȵ�¼�������ԣ�');
    }
});
router.get('/out', function(req, res, next) {
    req.session.user=null;
    res.json({code:200,msg:'ɾ���ɹ�'})
});
module.exports = router;
