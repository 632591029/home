var express = require('express');
var indexModel = require('../model/loadindex');
var router = express.Router();

/* GET home page. */
router.get('/index', function(req, res, next) {
  indexModel.indexload((rows)=>{
    console.log(rows);
     return res.json(rows);
  })
});

module.exports = router;
