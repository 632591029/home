var express = require('express');
var cartModel = require('../model/cartModel');
var router = express.Router();
router.get('/load',function(req,res,next){
    //console.log(req.session.user)
    if(req.session.user){
        var user=req.session.user;
        var uid=user.uid;
        cartModel.load(uid,(rows)=>{
            res.json(rows);
            //console.log(66666666666666666666666666666666666666666666666666)
        })
    }else{
        res.json({code:300,msg:'login required'})
    }
});
router.post('/del',function(req,res,next){
    let iid = req.body.iid;
    cartModel.del(iid,(rows)=>{
        if(rows=='succ'){
            res.json({code:200,msg:"delete succ"})
        }else{
            res.json({code:500,msg:"delete err"})
        }
    })
});
router.post('/update_count',function(req,res,next){
    if(req.session.user){
        let detail = req.body;
        cartModel.update(detail,(rows)=>{
            if(rows='succ'){
                res.json({code:200,msg:"update succ"})
            }else{
                res.json({code:500,msg:"update err"})
            }
        })
    }else{
        res.json({code:300,msg:'login required'})
    }
});
router.get('/list_checked',(req,res,next)=>{
    if(req.session.user){
        let id = req.session.user.uid;
        cartModel.checked(id,(rows)=>{
            res.json(rows);
        })
    }else{
        res.json({code:300,msg:'login required'})
    }
})
module.exports = router;
