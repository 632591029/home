
const pool = require('./pool')
let productModel = {};
productModel.load = function(lid,cb){
    var output={};
    pool.query('SELECT * FROM xz_laptop WHERE lid='+lid,(err,rows)=>{
        if(err)throw err;
        output.details=rows;
        output.details=output.details[0]
        pool.query('SELECT * FROM xz_laptop_pic WHERE laptop_id='+lid+' ORDER BY pid',(err,rows)=>{
            if(err)throw err;
            output.details.picList=rows;
            var fid =output.details.family_id;
            pool.query('SELECT * FROM xz_laptop_family WHERE fid='+fid,(err,rows)=>{
                if(err)throw err;
                output.family=rows;
                pool.query('SELECT lid,spec FROM xz_laptop WHERE family_id='+fid,(err,rows)=>{
                    if(err)throw err;
                    output.family[0].laptopList=rows;
                    cb(output);
                })
            })
        })
    })
};
productModel.add=function(uid,buyDetail,cb){
    let lid= buyDetail.lid/1;
    let buyCount=buyDetail.buyCount/1;
    pool.query("SELECT iid FROM xz_shoppingcart_item WHERE user_id="+uid+" AND product_id="+lid,(err,rows)=>{
        if(err) throw err;
        let sql;
        if(rows.length>0){
            pool.query("SELECT count FROM xz_shoppingcart_item WHERE user_id="+uid+" AND product_id="+lid,(err,rows)=>{
                let count = rows[0].count/1+1;
                //console.log('即将进入错误')
                sql = "UPDATE xz_shoppingcart_item SET count="+count+" WHERE user_id="+uid+" AND product_id="+lid;
                console.log(sql);
                pool.query(sql,(err,rows)=>{
                    if(err) throw err;
                    if(rows){
                        cb('succ');
                    }else{
                        cb('err');
                    }
                })
            })
        }else{
             sql = "INSERT INTO xz_shoppingcart_item VALUES(NULL, "+uid+", "+lid+", "+buyCount+", false)";
            pool.query(sql,(err,rows)=>{
                if(err) throw err;
                if(rows){
                    cb('succ');
                }else{
                    cb('err');
                }
            })
        }

    })
}
productModel.loadlist= function(kw,pno,cb){
    if(!pno){
        pno=1;
    }else{
        pno=pno/1;
    }
    var output = {
        recordCount: 0,
        pageSize : 9,
        pageCount:0,
        pno: pno,
        data : null}
    var sql ='SELECT COUNT(*) as row FROM xz_laptop';
    var add;
    if(kw){
        sql += " WHERE title LIKE ?;";
        add = ['%'+ kw +'%'];
    }
    pool.query(sql,add,(err,rows)=>{
        if(err)throw err;
        output.recordCount=rows[0].row;
        output.pageCount = Math.ceil(output.recordCount/output.pageSize);
        var start = (output.pno-1)*output.pageSize;
        var count = output.pageSize;
        var sql1=kw?"WHERE title LIKE '%"+kw+"%'":"";
        var sql = "SELECT lid,title,price,sold_count,is_onsale FROM xz_laptop "+sql1;
        sql+="ORDER BY sold_count DESC LIMIT "+start+","+count;
        var list ;
        pool.query(sql,(err,rows)=>{
            if(err)throw err;
            list =rows;
            //var count;
            let count = 0;
            for(let i=0;i<list.length;i++){
                var lid = list[i].lid;
                var sql = "SELECT md FROM xz_laptop_pic WHERE laptop_id="+lid+" LIMIT 0,1";
                (function(sql){pool.query(sql,(err,rows)=>{
                    if(err) throw err;
                    list[i].pic= rows[0].md;
                    count++;
                    //count++
                    if(count==list.length){
                        output.data=list;
                        cb(output);
                    }
                })})(sql)
            }



        })
    })
}
module.exports= productModel;