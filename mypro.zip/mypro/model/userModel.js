const pool = require('./pool')
let userModel = {};
userModel.login = function(user,cb){
    pool.query('SELECT uid FROM xz_user WHERE uname=? AND upwd= ?  ',
        [user.uname,user.upwd],(err,rows)=>{
            if(err)throw err;
            console.log(rows)
            if(rows.length>0){
                cb(rows[0].uid);
            }else{
                cb('err')
            }
        })
};
userModel.register = function(user,cb){
    pool.query('INSERT INTO xz_user SET ?',user, (err,rows)=>{
        if(err)throw err;
        cb(rows.insertId);
    })
};
module.exports= userModel;