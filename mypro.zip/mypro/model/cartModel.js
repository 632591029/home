const pool = require('./pool');
let cartModel = {};
cartModel.load=function(uid,cb){
    let sql = "SELECT iid,lid,title,spec,price,count FROM xz_laptop l, xz_shoppingcart_item s WHERE l.lid=s.product_id AND user_id="+uid;
    console.log(sql);
    pool.query(sql,(err,rows)=>{
        if(err) throw err;
        let list=rows;
        console.log(list)
        let output ={code:200,data:list}
        cb(output);
        //let count=0;
        //
        //for(let i=0;i<list.length;i++){
        //    let p=list[i];
        //    let sql="SELECT sm FROM xz_laptop_pic WHERE laptop_id="+p.lid+" LIMIT 1";
        //    (function(sql){pool.query(sql,(err,rows)=>{
        //        if(err) throw err;
        //        list[i].pic=rows[0];
        //        count++;
        //        if(count==list.length){
        //
        //
        //            console.log(66666666666666666666666666666666666666666666666666666666666666666666666666);
        //        }
        //    })})(sql)
        //}
    })
};
cartModel.del=function(iid,cb){
    pool.query("DELETE FROM xz_shoppingcart_item WHERE iid="+iid,(err,rows)=>{
        if(err) throw err;
        if(rows){
            cb('succ');
        }else{
            cb('err');
        }
    })
};
cartModel.update=function(detail,cb){
    let iid = detail.iid;
    let count=detail.count;
    pool.query("UPDATE xz_shoppingcart_item SET count="+count+" WHERE iid="+iid,(err,rows)=>{
        if(err) throw err;
        if(rows){
            cb('succ');
        }else{
            cb('err');
        }
    })
};
cartModel.checked=function(id,cb){
    let output={
        code:'',
        data:''
    }
    let sql = "SELECT iid,lid,title,spec,price,count FROM xz_laptop l, xz_shoppingcart_item s WHERE l.lid=s.product_id AND user_id="+id+" AND is_checked=1";
    pool.query(sql,(err,rows)=>{
        if(err) throw err;
        console.log(666666666)
        console.log(rows)
        let list =rows;
        let count=0;
        for(let i=0;i<rows.length;i++){
            let p =list[i];
            let sql ="SELECT sm FROM xz_laptop_pic WHERE laptop_id="+p.lid+" LIMIT 1";
            (function(sql){pool.query(sql,(err,rows)=>{
                if(err) throw err;
                console.log(rows[0])
                list[i].pic=rows[0];
                count++;
                if(count==rows.length){
                    output.code=200;
                    output.data=list;
                    cb(output);
                }
            })})(sql)

        }
    })
}
module.exports= cartModel;