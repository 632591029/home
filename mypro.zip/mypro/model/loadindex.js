const pool = require('./pool')
let indexModel = {};
indexModel.indexload = function(cb){
    var arr = {};
    //cb(123);
    pool.query('SELECT cid,img,title,href FROM xz_index_carousel',
        (err,rows)=>{
           if(err)throw err
            arr.carouselItems=rows;
            pool.query('SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_recommended>0 ORDER BY seq_recommended  LIMIT 6',
                (err,rows)=>{
                    if(err)throw err
                    arr.recommendedItems=rows;
                    pool.query('SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_new_arrival>0 ORDER BY seq_new_arrival LIMIT 6',
                        (err,rows)=>{
                            if(err)throw err
                            arr.newArrivalItems=rows;
                            pool.query('SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_top_sale>0 ORDER BY seq_top_sale LIMIT 6',
                                (err,rows)=>{
                                    if(err)throw err
                                    arr.topSaleItems=rows;
                                    cb(arr)
                                })
                        })
                })
        })



};
//pool.query('SELECT cid,img,title,href FROM xz_index_carousel;SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_recommended>0 ORDER BY seq_recommended  LIMIT 6;SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_new_arrival>0 ORDER BY seq_new_arrival LIMIT 6;SELECT pid,title,details,pic,price,href FROM xz_index_product WHERE seq_top_sale>0 ORDER BY seq_top_sale LIMIT 6',(err,rows)=>{
//    if(err) throw err;
//    arr['carouselItems']=rows[0];
//    arr['recommendedItems']=rows[1];
//    arr['newArrivalItems']=rows[2];
//    arr['topSaleItems']=rows[3];
//    cb(arr);
//});

module.exports= indexModel;