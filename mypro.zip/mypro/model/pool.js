const mysql =require ('mysql')
let  pool = mysql.createPool({
    host:'w.rdc.sae.sina.com.cn',
    user:'5xxzxkyoxw',
    password:'5z2hxlhy3j3wkk52mi0jmxhzz3531h4hx0lm5w1z',
    database:'app_2000homes',
    port:3306

})
module .exports=pool